import { Component } from '@angular/core';

@Component({
  selector: 'app-sample-page2',
  standalone: true,
  imports: [],
  templateUrl: './sample-page2.component.html',
  styleUrl: './sample-page2.component.scss'
})
export class SamplePage2Component {

}
